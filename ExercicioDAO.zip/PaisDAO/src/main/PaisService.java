package main;


import main.PaisD;
import main.Pais;

	public class PaisService {
	PaisD dao = new PaisD();
	
	public int incluir(Pais pais) {
		return dao.incluir(pais);
	}
	
	public void atualizar(Pais pais){
		dao.atualizar(pais);
	}
	
	public void excluir(int id){
		dao.excluir(id);
	}
	
	public clienteCarregar (int id){
		return dao.carregar(id);
	}

}
